#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @author ${USER}
* @date ${DATE} ${TIME}
* @description ${NAME}
*/
public interface ${NAME} {
}
